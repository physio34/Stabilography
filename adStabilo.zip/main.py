"""
Утилита для анализа стабилограмм и генерации отчетов в форматах HTML и XLSX.

Скрипт реализует расчет основных стабилометрических показателей:
- Путь и средняя скорость движения ЦД (Центра Давления)
- СРЕДНЕКВАДРАТИЧЕСКОЕ отклонение (RMS) по осям X и Y
- Площадь статокинезиограммы (95% эллипс)
- Разброс (амплитуда) по осям
- Частотный анализ (FFT): Общая мощность, средняя, медианная и пиковая частоты
"""

import logging
import argparse
from pathlib import Path
from typing import Dict, Tuple, List

import numpy as np
import pandas as pd
import plotly.graph_objects as go
from plotly.subplots import make_subplots

# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)

# Константы для расчетов
CHI_SQUARE_95 = 2.4477  # Критическое значение хи-квадрат для 2 степеней свободы (p=0.05)

def load_stabilogram(file_path: Path) -> pd.DataFrame:
    """Загружает данные стабилограммы из CSV или XLSX файла."""
    logger.info(f"Загрузка данных из: {file_path}")

    if not file_path.exists():
        raise FileNotFoundError(f"Файл не найден: {file_path}")

    if file_path.suffix.lower() == '.csv':
        df = pd.read_csv(file_path)
    elif file_path.suffix.lower() in ['.xlsx', '.xls']:
        df = pd.read_excel(file_path)
    else:
        raise ValueError("Неподдерживаемый формат файла. Используйте CSV или XLSX.")

    required_cols = {'X', 'Y'}
    if not required_cols.issubset(df.columns):
        raise ValueError(f"Данные должны содержать колонки: {required_cols}. Найдены: {df.columns.tolist()}")

    df = df.dropna(subset=['X', 'Y']).reset_index(drop=True)

    if 'Time' not in df.columns:
        logger.warning("Колонка 'Time' не найдена. Создана искусственная ось времени (50 Гц).")
        df['Time'] = np.arange(len(df)) / 50.0

    return df

def compute_psd(signal: np.ndarray, fs: float) -> Tuple[np.ndarray, np.ndarray]:
    """
    Вычисляет спектральную плотность мощности (PSD) для одномерного сигнала.
    Использует окно Хэннинга для уменьшения утечки спектра.
    """
    signal = signal - np.mean(signal)  # Удаление постоянной составляющей (DC offset)
    n = len(signal)
    if n < 2:
        return np.array([0]), np.array([0])

    window = np.hanning(n)
    signal_windowed = signal * window

    # Односторонний спектр
    fft_vals = np.fft.rfft(signal_windowed)
    power_spectrum = (np.abs(fft_vals)**2) / (fs * np.sum(window**2))
    freqs = np.fft.rfftfreq(n, d=1/fs)

    # Исключаем 0 Гц
    if len(freqs) > 1:
        freqs = freqs[1:]
        power_spectrum = power_spectrum[1:]

    return freqs, power_spectrum

def calculate_frequency_metrics(df: pd.DataFrame, fs: float) -> Dict[str, float]:
    """Рассчитывает частотные характеристики сигнала."""
    logger.info("Выполнение частотного анализа (FFT)...")
    metrics = {}

    for axis in ['X', 'Y']:
        signal = df[axis].values
        freqs, power = compute_psd(signal, fs)

        total_power = np.sum(power)
        if total_power > 0:
            mean_freq = np.sum(freqs * power) / total_power
            cumulative_power = np.cumsum(power)
            median_freq_idx = np.searchsorted(cumulative_power, total_power / 2)
            median_freq = freqs[min(median_freq_idx, len(freqs)-1)]
            peak_freq = freqs[np.argmax(power)]
        else:
            mean_freq = median_freq = peak_freq = 0.0

        metrics[f'Общая мощность {axis} (мм²/Гц)'] = total_power
        metrics[f'Средняя частота {axis} (Гц)'] = mean_freq
        metrics[f'Медианная частота {axis} (Гц)'] = median_freq
        metrics[f'Пиковая частота {axis} (Гц)'] = peak_freq

    return metrics

def calculate_metrics(df: pd.DataFrame) -> Dict[str, float]:
    """Рассчитывает основные стабилометрические метрики."""
    logger.info("Расчет стабилометрических метрик...")

    x = df['X'].values
    y = df['Y'].values
    time = df['Time'].values

    # Частота дискретизации
    time_diffs = np.diff(time)
    fs = 1.0 / np.mean(time_diffs) if len(time_diffs) > 0 and np.mean(time_diffs) > 0 else 50.0

    total_time = time[-1] - time[0]
    n_samples = len(x)

    # 1. Путь и скорость
    dx = np.diff(x)
    dy = np.diff(y)
    path_length = np.sum(np.sqrt(dx**2 + dy**2))
    mean_velocity = path_length / total_time if total_time > 0 else 0.0

    # 2. Среднеквадратическое отклонение (RMS)
    rms_x = np.sqrt(np.mean(x**2 - np.mean(x)**2)) if n_samples > 1 else 0.0
    rms_y = np.sqrt(np.mean(y**2 - np.mean(y)**2)) if n_samples > 1 else 0.0

    # 3. Разброс (Amplitude)
    range_x = np.max(x) - np.min(x)
    range_y = np.max(y) - np.min(y)

    # 4. Площадь 95% эллипса (Статокинезиограмма)
    x_c = x - np.mean(x)
    y_c = y - np.mean(y)
    cov_matrix = np.cov(x_c, y_c)

    try:
        eigenvalues, _ = np.linalg.eigh(cov_matrix)
        order = eigenvalues.argsort()[::-1]
        eigenvalues = eigenvalues[order]
        a = np.sqrt(eigenvalues[0]) * CHI_SQUARE_95
        b = np.sqrt(eigenvalues[1]) * CHI_SQUARE_95
        ellipse_area = np.pi * a * b
    except np.linalg.LinAlgError:
        logger.error("Ошибка вычисления ковариационной матрицы. Площадь установлена в 0.")
        ellipse_area = 0.0

    # Объединение временных и частотных метрик
    metrics = {
        'Общее время (с)': total_time,
        'Частота дискретизации (Гц)': fs,
        'Количество точек': n_samples,
        'Длина пути (мм)': path_length,
        'Средняя скорость (мм/с)': mean_velocity,
        'СКО по оси X (мм)': rms_x,
        'СКО по оси Y (мм)': rms_y,
        'Размах по оси X (мм)': range_x,
        'Размах по оси Y (мм)': range_y,
        'Площадь 95% эллипса (мм²)': ellipse_area
    }

    freq_metrics = calculate_frequency_metrics(df, fs)
    metrics.update(freq_metrics)

    return metrics

def generate_xlsx_report(metrics: Dict[str, float], raw_data: pd.DataFrame, output_path: Path) -> None:
    """Сохраняет метрики и сырые данные в XLSX файл."""
    logger.info(f"Генерация XLSX отчета: {output_path}")

    with pd.ExcelWriter(output_path, engine='openpyxl') as writer:
        df_metrics = pd.DataFrame(list(metrics.items()), columns=['Показатель', 'Значение'])
        df_metrics.to_excel(writer, sheet_name='Метрики', index=False)
        raw_data.to_excel(writer, sheet_name='Сырые данные', index=False)

def generate_html_report(df: pd.DataFrame, metrics: Dict[str, float], output_path: Path) -> None:
    """Создает интерактивный HTML отчет с графиками и таблицей метрик."""
    logger.info(f"Генерация HTML отчета: {output_path}")

    x = df['X'].values
    y = df['Y'].values
    time = df['Time'].values

    # Расчет параметров эллипса
    x_c = x - np.mean(x)
    y_c = y - np.mean(y)
    cov_matrix = np.cov(x_c, y_c)
    eigenvalues, eigenvectors = np.linalg.eigh(cov_matrix)
    order = eigenvalues.argsort()[::-1]
    eigenvalues = eigenvalues[order]
    eigenvectors = eigenvectors[:, order]

    a = np.sqrt(eigenvalues[0]) * CHI_SQUARE_95
    b = np.sqrt(eigenvalues[1]) * CHI_SQUARE_95
    angle = np.degrees(np.arctan2(eigenvectors[1, 0], eigenvectors[0, 0]))

    t = np.linspace(0, 2 * np.pi, 100)
    ellipse_x = a * np.cos(t)
    ellipse_y = b * np.sin(t)

    R = np.array([[np.cos(np.radians(angle)), -np.sin(np.radians(angle))],
                  [np.sin(np.radians(angle)), np.cos(np.radians(angle))]])
    ellipse_pts = R @ np.array([ellipse_x, ellipse_y])
    ellipse_x = ellipse_pts[0, :] + np.mean(x)
    ellipse_y = ellipse_pts[1, :] + np.mean(y)

    # Расчет PSD для графиков
    time_diffs = np.diff(time)
    fs = 1.0 / np.mean(time_diffs) if len(time_diffs) > 0 else 50.0
    freqs_x, power_x = compute_psd(x, fs)
    freqs_y, power_y = compute_psd(y, fs)

    fig = make_subplots(
        rows=3, cols=2,
        specs=[[{"colspan": 2}, None], [{"type": "xy"}, {"type": "xy"}], [{"type": "xy"}, {"type": "xy"}]],
        subplot_titles=(
            "Статокинезиограмма (X vs Y)",
            "Отклонение по X",
            "Отклонение по Y",
            "Спектр мощности X (PSD)",
            "Спектр мощности Y (PSD)"
        ),
        vertical_spacing=0.08
    )

    # График 1: Статокинезиограмма
    fig.add_trace(go.Scatter(x=x, y=y, mode='lines+markers', name='Траектория ЦД', line=dict(width=1, color='blue'), marker=dict(size=3)),
                  row=1, col=1)
    fig.add_trace(go.Scatter(x=ellipse_x, y=ellipse_y, mode='lines', name='95% Эллипс', line=dict(color='red', width=2, dash='dash')),
                  row=1, col=1)

    # Графики 2 & 3: Отклонения по времени
    fig.add_trace(go.Scatter(x=time, y=x, mode='lines', name='Ось X', line=dict(color='green', width=1)), row=2, col=1)
    fig.add_trace(go.Scatter(x=time, y=y, mode='lines', name='Ось Y', line=dict(color='orange', width=1)), row=2, col=2)

    # Графики 4 & 5: Спектры мощности
    fig.add_trace(go.Scatter(x=freqs_x, y=power_x, mode='lines', name='PSD X', line=dict(color='green', width=1.5)), row=3, col=1)
    fig.add_trace(go.Scatter(x=freqs_y, y=power_y, mode='lines', name='PSD Y', line=dict(color='orange', width=1.5)), row=3, col=2)

    # Настройка осей
    fig.update_xaxes(title_text="X (мм)", row=1, col=1)
    fig.update_yaxes(title_text="Y (мм)", row=1, col=1, scaleanchor="x", scaleratio=1) # Равный масштаб

    fig.update_xaxes(title_text="Время (с)", row=2, col=1)
    fig.update_yaxes(title_text="Отклонение (мм)", row=2, col=1)
    fig.update_xaxes(title_text="Время (с)", row=2, col=2)
    fig.update_yaxes(title_text="Отклонение (мм)", row=2, col=2)

    fig.update_xaxes(title_text="Частота (Гц)", type="log", row=3, col=1)
    fig.update_yaxes(title_text="Мощность (мм²/Гц)", type="log", row=3, col=1)
    fig.update_xaxes(title_text="Частота (Гц)", type="log", row=3, col=2)
    fig.update_yaxes(title_text="Мощность (мм²/Гц)", type="log", row=3, col=2)

    fig.update_layout(title_text="Отчет анализа стабилограммы", showlegend=True, height=1200, width=1000)

    # Таблица метрик
    metrics_html = "<table border='1' style='border-collapse: collapse; width: 100%; text-align: left; margin-top: 20px; font-family: Arial, sans-serif;'>"
    metrics_html += "<tr style='background-color: #f2f2f2;'><th>Показатель</th><th>Значение</th></tr>"
    for key, val in metrics.items():
        if isinstance(val, float):
            val_str = f"{val:.4f}"
        else:
            val_str = str(val)
        metrics_html += f"<tr><td>{key}</td><td>{val_str}</td></tr>"
    metrics_html += "</table>"

    html_string = fig.to_html(full_html=False, include_plotlyjs='cdn')

    with open(output_path, 'w', encoding='utf-8') as f:
        f.write("<html><head><title>Stabilogram Report</title></head><body>")
        f.write("<h1>Анализ стабилограммы</h1>")
        f.write(html_string)
        f.write(metrics_html)
        f.write("</body></html>")

def main():
    parser = argparse.ArgumentParser(description="Анализ стабилограмм и генерация отчетов (включая частотный анализ).")
    parser.add_argument('input_file', type=str, help='Путь к входному файлу (CSV/XLSX)')
    parser.add_argument('-o', '--output_dir', type=str, default='.', help='Директория для сохранения отчетов')

    args = parser.parse_args()

    input_path = Path(args.input_file)
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    try:
        df = load_stabilogram(input_path)
        metrics = calculate_metrics(df)

        for k, v in metrics.items():
            if isinstance(v, float):
                logger.info(f"{k}: {v:.4f}")
            else:
                logger.info(f"{k}: {v}")

        base_name = input_path.stem
        xlsx_path = output_dir / f"{base_name}_report.xlsx"
        html_path = output_dir / f"{base_name}_report.html"

        generate_xlsx_report(metrics, df, xlsx_path)
        generate_html_report(df, metrics, html_path)

        logger.info("Анализ успешно завершен!")

    except Exception as e:
        logger.error(f"Критическая ошибка при обработке файла: {e}", exc_info=True)

if __name__ == "__main__":
    main()